package com.leap.finance.service;

import org.springframework.stereotype.Service;

import com.leap.finance.dto.APIResponse;
import com.leap.finance.dto.TaskDto;

@Service
public interface TodoService {

	public APIResponse getTodoTaskList();
	
	public APIResponse addNewTodoTask(TaskDto taskDto);

	public APIResponse updateTaskDetails(int taskDto, TaskDto taskDetails);

	public APIResponse deleteTaskById(int id);

	

}
